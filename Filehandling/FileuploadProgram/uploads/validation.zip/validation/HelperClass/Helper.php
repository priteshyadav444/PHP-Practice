<?php
include 'Pincode/Pincode.php';
include 'Error/Error.php';
include 'Object/Object.php';
include 'Test/Test.php';
