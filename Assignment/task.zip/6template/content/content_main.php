<!-- about -->
<?php include 'about.php'; ?>
<!-- end about -->
<!-- classified  section -->
<?php include 'classified.php'; ?>
<!-- end classified  section -->
<!-- review -->
<?php include 'review.php'; ?>
<!-- end review -->