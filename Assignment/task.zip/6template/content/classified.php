<div class="classified ">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="titlepage">
                    <h2>ONE OF THE BEST <span class="blu"> classified</span></h2>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                        <div class="classified_box">
                            <span>0<strong class="blu2">1</strong>.</span>
                        </div>
                    </div>
                    <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12">
                        <div class="classified_box">
                            <div class="fornt">
                                <h3> FRONT END MULTICURRENCY</h3>
                                <p>using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                            <div class="classified_box">
                                <span>0<strong class="blu2">2</strong>.</span>
                            </div>
                        </div>
                        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12">
                            <div class="classified_box">
                                <div class="fornt">
                                    <h3>MOST INTELLIGENT SEARCH SYSTEM</h3>
                                    <p>using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                            <div class="classified_box">
                                <span>0<strong class="blu2">3</strong>.</span>
                            </div>
                        </div>
                        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12">
                            <div class="classified_box">
                                <div class="fornt">
                                    <h3>MOST INTELLIGENT SEARCH SYSTEM</h3>
                                    <p>using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>