1) Each Folder Have Their Main Page
    Header
        header_main.php
    Content
        contact_main.pph
    Footer
        footer_main.php
2) Divided Template in Three Section 
    Header
    Content
        About
        Classied
        Review
    Footer
       Contact Us Form