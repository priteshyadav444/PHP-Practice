<form id="request" class="main_form">
    <div class="row">
        <div class="col-md-12 ">
            <input class="contactus" placeholder="Full Name" type="type" name="Full Name">
        </div>
        <div class="col-md-12">
            <input class="contactus" placeholder="Email" type="type" name="Email">
        </div>
        <div class="col-md-12">
            <input class="contactus" placeholder="Phone Number" type="type" name="Phone Number">
        </div>
        <div class="col-md-12">
            <textarea class="textarea" placeholder="Message" type="type" Message="Name">Message </textarea>
        </div>
        <div class="col-sm-col-xl-6 col-lg-6 col-md-6 col-sm-12">
            <button class="send_btn">Send</button>
        </div>
        <div class="col-sm-col-xl-6 col-lg-6 col-md-6 col-sm-12">
            <ul class="social_icon">
                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
            </ul>
        </div>
    </div>
</form>